package com.example.BookStore.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.BookStore.entity.MyBookList;

public interface MyBookRepository extends JpaRepository<MyBookList,Integer>{

}
